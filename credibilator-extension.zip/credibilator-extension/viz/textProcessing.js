(function (window, undefined) {

    var textProcessing = function(){
        
        
        
        
    }
    
    textProcessing.prototype.findSentenceNeighborsInCorpus = function(listOfSentences){
        listOfSentences

        
	}
    
    

// List functions you want other scripts to access
    window.textProcessing = {
        textProcessing: textProcessing
    };
})(window)